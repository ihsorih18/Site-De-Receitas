<?php include 'db_connection.php'; ?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Resultados da Pesquisa</title>
    <style>
        /* Estilo da página de pesquisa para harmonizar com a principal */

        /* Centraliza e estiliza o contêiner dos resultados */
        .search-results-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            text-align: center;
        }

        h1 {
            font-size: 28px;
            color: #333;
            margin-bottom: 20px;
        }

        /* Lista dos resultados */
        .results-list {
            list-style-type: none;
            padding: 0;
        }

        /* Cada item de resultado */
        .results-list li {
            margin: 15px 0;
            padding: 15px;
            border-radius: 8px;
            background-color: #f4f4f4;
            transition: background-color 0.3s ease;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        /* Link do título da receita */
        .results-list li a {
            text-decoration: none;
            color: #333;
            font-size: 20px;
            font-weight: bold;
            display: block;
        }

        /* Efeito ao passar o mouse */
        .results-list li:hover {
            background-color: #e0e0e0;
        }

        /* Mensagem de erro caso não encontre receitas */
        .no-results {
            color: #666;
            font-size: 18px;
        }
    </style>
</head>
<body>
    <div class="search-results-container">
        <h1>Resultados da Pesquisa</h1>

        <?php
        // Recebe o termo de pesquisa do formulário
        if (isset($_GET['termo'])) {
            $termo = $_GET['termo'];

            // Consulta as receitas que contêm o termo pesquisado no título
            $sql = "SELECT id, titulo FROM receitas WHERE titulo LIKE '%$termo%'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<ul class='results-list'>";
                // Exibe cada receita encontrada como um link
                while($row = $result->fetch_assoc()) {
                    echo "<li><a href='receita.php?id=" . $row['id'] . "'>" . $row['titulo'] . "</a></li>";
                }
                echo "</ul>";
            } else {
                echo "<p class='no-results'>Nenhuma receita encontrada para o termo '$termo'.</p>";
            }
        } else {
            echo "<p class='no-results'>Por favor, digite um termo de pesquisa.</p>";
        }

        $conn->close();
        ?>
    </div>
</body>
</html>
