<?php include 'db_connection.php'; ?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Detalhes da Receita</title>
    <style>
        /* Estilos da página de receita */

        .recipe-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .recipe-title {
            font-size: 28px;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }

        .recipe-image {
            max-width: 300px; /* Tamanho reduzido da imagem */
            width: 100%;
            height: auto;
            border-radius: 8px;
            margin: 20px auto;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.15);
        }

        .recipe-description,
        .recipe-ingredients,
        .recipe-preparation {
            text-align: left;
            color: #555;
            line-height: 1.6;
        }

        /* Subtítulos das seções */
        .recipe-section-title {
            font-size: 22px;
            color: #333;
            margin-top: 20px;
            margin-bottom: 10px;
            border-bottom: 2px solid #ddd;
            padding-bottom: 5px;
        }

        /* Estilização dos textos */
        .recipe-content p {
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div class="recipe-container">
        <?php
        if (isset($_GET['id'])) {
            $id = $_GET['id'];

            // Consulta a receita específica pelo ID
            $sql = "SELECT * FROM receitas WHERE id = $id";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                
                // Título
                echo "<h1 class='recipe-title'>" . $row['titulo'] . "</h1>";

                // Imagem
                echo "<img src='" . $row['imagem'] . "' alt='" . $row['titulo'] . "' class='recipe-image'>";

                // Descrição
                echo "<div class='recipe-description'>";
                echo "<h2 class='recipe-section-title'>Descrição</h2>";
                echo "<p>" . nl2br($row['descricao']) . "</p>";
                echo "</div>";

                // Ingredientes
                echo "<div class='recipe-ingredients'>";
                echo "<h2 class='recipe-section-title'>Ingredientes</h2>";
                echo "<p>" . nl2br($row['ingredientes']) . "</p>";
                echo "</div>";

                // Modo de Preparo
                echo "<div class='recipe-preparation'>";
                echo "<h2 class='recipe-section-title'>Modo de Preparo</h2>";
                echo "<p>" . nl2br($row['modo_preparo']) . "</p>";
                echo "</div>";
            } else {
                echo "<p>Receita não encontrada.</p>";
            }
        } else {
            echo "<p>Nenhuma receita selecionada.</p>";
        }

        $conn->close();
        ?>
    </div>
</body>
</html>
